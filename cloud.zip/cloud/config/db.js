const mongoose = require('mongoose');

const MONGO_URI = 'mongodb+srv://rdam1116:POVFrm6RxAWwsSII@cluster0.e6pzb.mongodb.net/myDatabase?retryWrites=true&w=majority';

const connectDB = async () => {
    try {
        await mongoose.connect(MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB Connected');
    } catch (error) {
        console.error('Database connection error:', error);
        process.exit(1);
    }
};

module.exports = connectDB;
